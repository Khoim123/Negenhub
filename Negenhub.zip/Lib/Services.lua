-- Lib/Services.lua
-- Tập hợp tất cả services và references dùng chung
return function()
    local Players           = game:GetService("Players")
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    
    return {
        Players           = Players,
        RunService        = game:GetService("RunService"),
        Lighting          = game:GetService("Lighting"),
        UserInputService  = game:GetService("UserInputService"),
        TweenService      = game:GetService("TweenService"),
        ReplicatedStorage = ReplicatedStorage,
        HttpService       = game:GetService("HttpService"),
        VirtualUser       = game:GetService("VirtualUser"),
        LocalPlayer       = Players.LocalPlayer,
        Events            = ReplicatedStorage:WaitForChild("Events"),
    }
end