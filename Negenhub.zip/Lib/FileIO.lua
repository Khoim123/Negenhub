-- Lib/FileIO.lua
-- Đọc/ghi file JSON an toàn (hỗ trợ writefile + syn.writefile)
return function(S)
    local HttpService = S.HttpService
    
    local M = {}
    
    M.SPOTS_FILE_NAME             = "NegenHub_SavedSpots.json"
    M.SPOTS_FILE_PATH_IN_FOLDER   = "KhoiScriptSettings/NegenHub_SavedSpots.json"
    M.SPOTS_FOLDER                = "KhoiScriptSettings"
    
    -- Serialize CFrame → mảng 12 số
    function M.cframeToArray(cf)
        return { cf:GetComponents() }
    end
    
    -- Deserialize mảng 12 số → CFrame
    function M.arrayToCFrame(arr)
        if type(arr) ~= "table" or #arr ~= 12 then return nil end
        for i = 1, 12 do
            if type(arr[i]) ~= "number" then return nil end
        end
        return CFrame.new(
            arr[1], arr[2], arr[3],
            arr[4], arr[5], arr[6],
            arr[7], arr[8], arr[9],
            arr[10], arr[11], arr[12]
        )
    end
    
    -- Detect API file system
    function M.getFileAPIs()
        local apis = {}
        if type(writefile)  == "function" then table.insert(apis, "writefile") end
        if type(readfile)   == "function" then table.insert(apis, "readfile") end
        if type(isfile)     == "function" then table.insert(apis, "isfile") end
        if type(makefolder) == "function" then table.insert(apis, "makefolder") end
        if type(syn) == "table" then
            if type(syn.writefile) == "function" then table.insert(apis, "syn.writefile") end
            if type(syn.readfile)  == "function" then table.insert(apis, "syn.readfile") end
        end
        return apis
    end
    
    function M.safeWriteFile(path, content)
        if type(writefile) == "function" then
            local ok, err = pcall(writefile, path, content)
            if ok then return true, nil, path end
        end
        if type(syn) == "table" and type(syn.writefile) == "function" then
            local ok, err = pcall(syn.writefile, path, content)
            if ok then return true, nil, path end
        end
        return false, "no writefile API available", nil
    end
    
    function M.safeReadFile(path)
        if type(readfile) == "function" then
            local ok, content = pcall(readfile, path)
            if ok and type(content) == "string" then return content end
        end
        if type(syn) == "table" and type(syn.readfile) == "function" then
            local ok, content = pcall(syn.readfile, path)
            if ok and type(content) == "string" then return content end
        end
        return nil, "no readfile API available"
    end
    
    function M.persistSavedSpots(savedSpots)
        local apis = M.getFileAPIs()
        if #apis == 0 or (type(writefile) ~= "function" and (type(syn) ~= "table" or type(syn.writefile) ~= "function")) then
            return false, "executor không có writefile/syn.writefile", nil
        end
        
        local data = {}
        for name, cf in pairs(savedSpots) do
            data[name] = M.cframeToArray(cf)
        end
        local encOk, json = pcall(function() return HttpService:JSONEncode(data) end)
        if not encOk or not json then
            return false, "JSON encode thất bại", nil
        end
        
        if type(makefolder) == "function" then
            pcall(makefolder, M.SPOTS_FOLDER)
        end
        
        local paths = { M.SPOTS_FILE_PATH_IN_FOLDER, M.SPOTS_FILE_NAME }
        local lastErr = "không rõ"
        local usedPath = nil
        for _, path in ipairs(paths) do
            local ok, err = M.safeWriteFile(path, json)
            if ok then
                usedPath = path
                local verifyContent = M.safeReadFile(path)
                if verifyContent and #verifyContent > 0 then
                    return true, nil, usedPath
                end
                return true, "ghi OK nhưng verify-read không ra", usedPath
            end
            lastErr = err or lastErr
        end
        return false, lastErr, nil
    end
    
    function M.loadSavedSpots(savedSpots, notify)
        local apis = M.getFileAPIs()
        if #apis == 0 or (type(readfile) ~= "function" and (type(syn) ~= "table" or type(syn.readfile) ~= "function")) then
            notify("Saved Spots", "Executor không có readfile API. Spots sẽ không persist khi đổi server.", 5)
            return 0
        end
        
        local paths = { M.SPOTS_FILE_PATH_IN_FOLDER, M.SPOTS_FILE_NAME }
        local json, usedPath = nil, nil
        for _, path in ipairs(paths) do
            local content, _ = M.safeReadFile(path)
            if content and content ~= "" then
                json = content
                usedPath = path
                break
            end
        end
        
        if not json then return 0 end
        
        local decOk, data = pcall(function() return HttpService:JSONDecode(json) end)
        if not decOk or type(data) ~= "table" then
            notify("Saved Spots", "File lưu bị hỏng (JSON không parse được). Sẽ ghi đè lần save kế tiếp.", 4)
            return 0
        end
        
        local count = 0
        for name, arr in pairs(data) do
            local cf = M.arrayToCFrame(arr)
            if cf then
                savedSpots[name] = cf
                count = count + 1
            end
        end
        if count > 0 then
            notify("Saved Spots", string.format("Đã load %d spot từ disk (%s)", count, usedPath), 4)
        end
        return count
    end
    
    return M
end