-- Lib/GuiParent.lua
-- Lấy parent an toàn cho GUI (gethui → CoreGui → PlayerGui)
return function(S, U)
    local LocalPlayer = S.LocalPlayer
    
    local M = {}
    
    function M.getSafeGuiParent()
        if type(gethui) == "function" then
            local ok, hui = pcall(gethui)
            if ok and hui then return hui, false end
        end
        local ok, coreGui = pcall(function() return game:GetService("CoreGui") end)
        if ok and coreGui then
            if type(syn) == "table" and type(syn.protect_gui) == "function" then
                return coreGui, true
            end
            return coreGui, false
        end
        return LocalPlayer:WaitForChild("PlayerGui"), false
    end
    
    function M.parentGuiSafe(gui)
        local parent, needProtect = M.getSafeGuiParent()
        if needProtect and type(syn) == "table" and type(syn.protect_gui) == "function" then
            pcall(syn.protect_gui, gui)
        end
        gui.Parent = parent
        return parent
    end
    
    return M
end