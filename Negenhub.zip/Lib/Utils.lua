-- Lib/Utils.lua
-- Các hàm utility chung: notify, new, teleport, getChar/HRP/Hum, ...
return function(S)
    local LocalPlayer = S.LocalPlayer
    
    local M = {}
    local Fluent -- forward declaration
    
    function M.setFluent(f) Fluent = f end
    
    function M.notify(title, content, dur)
        if Fluent and Fluent.Notify then
            Fluent:Notify({ Title = title, Content = content, Duration = dur or 3 })
        end
    end
    
    function M.new(class, props, parent)
        local inst = Instance.new(class)
        for k, v in pairs(props or {}) do
            if k ~= "Parent" then inst[k] = v end
        end
        inst.Parent = parent or (props and props.Parent)
        return inst
    end
    
    function M.getChar(p) return p and p.Character end
    function M.getHRP(p)  local c = M.getChar(p); return c and c:FindFirstChild("HumanoidRootPart") end
    function M.getHum(p)  local c = M.getChar(p); return c and c:FindFirstChildOfClass("Humanoid") end
    
    -- Teleport mạnh mẽ với nhiều fallback
    function M.teleport(cframe)
        if typeof(cframe) ~= "CFrame" then
            return false, "Tọa độ không hợp lệ"
        end
        local char = LocalPlayer.Character
        if not char then
            return false, "Character chưa spawn (đợi game load)"
        end
        local hrp = char:FindFirstChild("HumanoidRootPart")
        if not hrp then
            hrp = char:WaitForChild("HumanoidRootPart", 2)
        end
        if not hrp then
            return false, "Không tìm thấy HumanoidRootPart"
        end
        
        local function killVelocity()
            pcall(function() hrp.AssemblyLinearVelocity  = Vector3.zero end)
            pcall(function() hrp.AssemblyAngularVelocity = Vector3.zero end)
        end
        
        local hum = char:FindFirstChildOfClass("Humanoid")
        local oldAutoRotate = hum and hum.AutoRotate
        if hum then pcall(function() hum.AutoRotate = false end) end
        local function restoreAutoRotate()
            if hum and hum.Parent and oldAutoRotate ~= nil then
                task.delay(0.4, function()
                    pcall(function() hum.AutoRotate = oldAutoRotate end)
                end)
            end
        end
        
        -- Phương pháp 1
        killVelocity()
        pcall(function() char:PivotTo(cframe) end)
        task.wait(0.08)
        if (hrp.Position - cframe.Position).Magnitude < 60 then
            killVelocity()
            pcall(function() hrp.CFrame = cframe end)
            restoreAutoRotate()
            return true
        end
        
        -- Phương pháp 2
        killVelocity()
        pcall(function() hrp.CFrame = cframe end)
        task.wait(0.08)
        if (hrp.Position - cframe.Position).Magnitude < 60 then
            killVelocity()
            restoreAutoRotate()
            return true
        end
        
        -- Phương pháp 3
        for _ = 1, 2 do
            killVelocity()
            pcall(function() char:PivotTo(cframe) end)
            task.wait(0.1)
            if (hrp.Position - cframe.Position).Magnitude < 60 then
                killVelocity()
                pcall(function() hrp.CFrame = cframe end)
                restoreAutoRotate()
                return true
            end
        end
        
        restoreAutoRotate()
        return false, "Teleport bị chặn (có thể do anti-cheat của game)"
    end
    
    -- Fly states
    M.FLY_STATES = {
        Enum.HumanoidStateType.Climbing, Enum.HumanoidStateType.FallingDown,
        Enum.HumanoidStateType.Flying,   Enum.HumanoidStateType.Freefall,
        Enum.HumanoidStateType.GettingUp, Enum.HumanoidStateType.Jumping,
        Enum.HumanoidStateType.Landed,   Enum.HumanoidStateType.Physics,
        Enum.HumanoidStateType.PlatformStanding, Enum.HumanoidStateType.Ragdoll,
        Enum.HumanoidStateType.Running,  Enum.HumanoidStateType.RunningNoPhysics,
        Enum.HumanoidStateType.Seated,   Enum.HumanoidStateType.StrafingNoPhysics,
        Enum.HumanoidStateType.Swimming,
    }
    
    function M.setHumanoidStates(hum, enabled)
        for _, st in ipairs(M.FLY_STATES) do hum:SetStateEnabled(st, enabled) end
    end
    
    function M.setToggle(Options, flagName, value)
        local t = Options[flagName]
        if t then pcall(function() t:SetValue(value) end) end
    end
    
    return M
end