-- Features/Shop.lua
-- Sell Fish, Favorite Fish, Buy Bait
return function(Shared)
    local S, U, Tabs = Shared.Services, Shared.Utils, Shared.Tabs
    local Events = S.Events
    
    local autoSellDelay         = 30
    local autoSellAllEnabled    = false
    local autoFavFishEnabled    = false
    local autoSellSelectEnabled = false
    local selectedFavFish       = {}
    
    local function fireRemote(remote, ...)
        if not remote then return false, "remote nil" end
        local ok, err = pcall(function(...) remote:FireServer(...) end, ...)
        if not ok then
            pcall(function(...) remote:InvokeServer(...) end, ...)
        end
        return ok, err
    end
    
    -- ==========================================
    -- Sell Fish Section
    -- ==========================================
    local SellFish = Tabs.Shop:AddSection("Sell Fish")
    
    SellFish:AddButton({
        Title = "Sell All Fish",
        Callback = function()
            local ok, err = fireRemote(Events.SellFish, "All")
            U.notify("Sell Fish", ok and "Đã gửi lệnh Sell All" or ("Lỗi: " .. tostring(err)))
        end,
    })
    
    SellFish:AddButton({
        Title = "Sell One Fish",
        Callback = function()
            local ok, err = fireRemote(Events.SellFish, "One")
            if not ok then U.notify("Sell Fish", "Lỗi: " .. tostring(err)) end
        end,
    })
    
    local SellFishSlider = SellFish:AddSlider("Sell Fish Slider", {
        Title    = "Delay Auto Sell Fish",
        Default  = 30,
        Min      = 1,
        Max      = 120,
        Rounding = 0,
        Callback = function(Value) autoSellDelay = Value end,
    })
    SellFishSlider:OnChanged(function(Value) autoSellDelay = Value end)
    
    local function autoSellAllLoop()
        while autoSellAllEnabled do
            local ok, err = fireRemote(Events.SellFish, "All")
            if not ok then
                U.notify("Auto Sell All", "Lỗi khi sell: " .. tostring(err), 3)
            end
            local waited = 0
            while autoSellAllEnabled and waited < autoSellDelay do
                task.wait(0.5)
                waited = waited + 0.5
            end
        end
    end
    
    SellFish:AddToggle("Auto Sell All Toggle", {
        Title   = "Auto Sell All",
        Default = false,
        Callback = function(state)
            autoSellAllEnabled = state
            if state then
                task.spawn(autoSellAllLoop)
                U.notify("Auto Sell All", string.format("Đã BẬT! Cứ %ss sell 1 lần", autoSellDelay))
            else
                U.notify("Auto Sell All", "Đã TẮT")
            end
        end,
    })
    
    -- ==========================================
    -- Fish Select Dropdown
    -- ==========================================
    local FavFishDropdown = SellFish:AddDropdownCanFind("Fish Select Dropdown", {
        Title  = "Fish Select",
        Values = {
            -- Beginning Isle & Bamboo Isle
            "Trout", "Catfish", "Crimson Catfish", "Crimson Carp", "Tilapia", "Arrogant Fish",
            "Horned Silver Carp", "Blackfin Grass Carp", "Crimsonfin Glass Carp",
            "Goldfin Grass Carp", "Rosefin Grass Carp", "Azurefin Grass Carp",
            "Sovereign Grass Carp", "Dragonhead Tilapia", "Elder Dragonhead Tilapia",
            "Spiked Salmon", "Platescale Tilapia", "Azure Salmon", "Sunscale Salmon",
            "Runic Horn Grouper", "Ironhorn Flounder", "Chainbound Shark",
            -- Fallout Isle & Sovereign Isle
            "Boundeye Fish", "Baby Jiaolong Dragonfish", "Gold Crucian Carp",
            "Dragonstride Carp", "Terratiger Depthfish III", "Terratiger Depthfish II",
            "Terratiger Depthfish I", "Adult Jiaolong Dragonfish", "Elder Chainbound Shark",
            "Elder Jiaolong Dragonfish", "Trueform Jiaolongfish", "Warbringer Shark",
            "Dragonscale Grouper", "Myriad Koi Whale",
            -- Perch Isle & Frost Isle
            "Elder Perch VIII", "Elder Perch VII", "Elder Perch VI", "Elder Perch V",
            "Elder Perch IV", "Elder Perch III", "Elder Perch II", "Elder Perch I",
            "Trueform Perch", "Ascended Perch", "Fleshripper Fish", "Kunfish III",
            "Kunfish II", "Kunfish I", "Adult Kunfish", "Elder Kunfish",
            "Primordial Kunfish", "Primordial Kunfish Overlord",
            -- Amber Isle, Battlefield Isle & Mistpeak Isle
            "Crimson Bream Sovereign", "Silver Bream Sovereign", "Golden Guardian Fish",
            "Colossal Tigerfish", "Verdant Alligator Gar", "Verdant Grouper", "Scarlet Fish",
            "Verdant Bonefang", "Elder Scarlet Fish", "Draconic Koi", "Flying Fish Empress",
            "Crimson Bonefang", "Tigerfang Whale", "Crimson Electric Eel", "Reborn Puffer Beast",
            "Sanguine Fish", "Frost Kingfish", "Sand Anchovy", "Abyssal Glow Fish",
            "Lapis Fish", "Grass Tilapia", "Scarlet Fringehead", "Stormscale Tautog",
            "Darkscale Fish", "Radiant Goldfish", "Serpent Fish", "Dreadmare Eel"
        },
        Multi = true,
    })
    
    FavFishDropdown:OnChanged(function(Value)
        selectedFavFish = {}
        if type(Value) == "table" then
            for k, v in next, Value do
                if type(v) == "string" then
                    table.insert(selectedFavFish, v)
                elseif type(v) == "boolean" and v == true then
                    table.insert(selectedFavFish, k)
                end
            end
        elseif type(Value) == "string" then
            table.insert(selectedFavFish, Value)
        end
        table.sort(selectedFavFish)
    end)
    
    -- ==========================================
    -- Auto Favorite Fish
    -- ==========================================
    local FAV_LOOP_INTERVAL = 3
    local function autoFavFishLoop()
        while autoFavFishEnabled do
            if #selectedFavFish == 0 then
                U.notify("Auto Favorite", "Chưa chọn cá nào trong Fish Select!", 3)
            else
                for _, fishName in ipairs(selectedFavFish) do
                    if not autoFavFishEnabled then break end
                    local ok, err = fireRemote(Events.FavoriteItem, fishName)
                    if not ok then
                        U.notify("Auto Favorite", "Lỗi favorite '" .. fishName .. "': " .. tostring(err), 5)
                        task.wait(2)
                        break
                    end
                    task.wait(0.15)
                end
            end
            local waited = 0
            while autoFavFishEnabled and waited < FAV_LOOP_INTERVAL do
                task.wait(0.5)
                waited = waited + 0.5
            end
        end
    end
    
    SellFish:AddToggle("Favorite Fish Toggle", {
        Title   = "Auto Favorite Fish Select",
        Default = false,
        Callback = function(state)
            autoFavFishEnabled = state
            if state then
                if #selectedFavFish == 0 then
                    U.notify("Auto Favorite", "Chưa chọn cá nào! Bật nhưng không có gì để favorite.", 3)
                end
                task.spawn(autoFavFishLoop)
                U.notify("Auto Favorite", "Đã BẬT! Tự favorite cá đã chọn mỗi " .. FAV_LOOP_INTERVAL .. "s")
            else
                U.notify("Auto Favorite", "Đã TẮT")
            end
        end,
    })
    
    -- ==========================================
    -- Auto Sell Selected Fish
    -- ==========================================
    local function autoSellSelectLoop()
        while autoSellSelectEnabled do
            if #selectedFavFish == 0 then
                U.notify("Auto Sell Select", "Chưa chọn cá nào trong Fish Select!", 3)
            else
                for _, fishName in ipairs(selectedFavFish) do
                    if not autoSellSelectEnabled then break end
                    local ok, err = fireRemote(Events.SellFish, fishName)
                    if not ok then
                        U.notify("[Auto Sell Select] Lỗi sell " .. fishName .. ": " .. tostring(err))
                    end
                    task.wait(0.15)
                end
            end
            local waited = 0
            while autoSellSelectEnabled and waited < autoSellDelay do
                task.wait(0.5)
                waited = waited + 0.5
            end
        end
    end
    
    SellFish:AddToggle("Auto Sell Fish Select Toggle", {
        Title   = "Auto Sell Fish Select",
        Default = false,
        Callback = function(state)
            autoSellSelectEnabled = state
            if state then
                if #selectedFavFish == 0 then
                    U.notify("Auto Sell Select", "Chưa chọn cá nào! Bật nhưng không có gì để sell.", 3)
                end
                task.spawn(autoSellSelectLoop)
                U.notify("Auto Sell Select", string.format("Đã BẬT! Cứ %ss sell cá đã chọn 1 lần", autoSellDelay))
            else
                U.notify("Auto Sell Select", "Đã TẮT")
            end
        end,
    })
    
    -- ==========================================
    -- Buy Bait Section
    -- ==========================================
    local BaitPrices = {
        ["Basic Bait"]             = 100,
        ["Crude Mash Bait"]        = 10000,
        ["Corrupted Essence Bait"] = 15000,
        ["Elite Bait"]             = 50000,
        ["Ancestral Bait"]         = 100000,
    }
    local BaitList = {
        "Basic Bait", "Crude Mash Bait", "Corrupted Essence Bait",
        "Elite Bait", "Ancestral Bait",
    }
    local BaitSelect = "Basic Bait"
    
    local BuyBaitSection = Tabs.Shop:AddSection("Buy Bait")
    local BaitPriceParagraph = BuyBaitSection:AddParagraph({ Title = "Bait Price: $100" })
    
    local function updateBaitPrice(value)
        BaitSelect = value
        local text = "Bait Price: $" .. (BaitPrices[value] or 0)
        if BaitPriceParagraph.SetTitle then    BaitPriceParagraph:SetTitle(text)
        elseif BaitPriceParagraph.Set then     BaitPriceParagraph:Set(text)
        elseif BaitPriceParagraph.SetText then BaitPriceParagraph:SetText(text) end
    end
    
    local BuyBaitDropdown = BuyBaitSection:AddDropdown("Buy Bait Dropdown", {
        Title  = "Select Bait",
        Values = BaitList,
        Multi  = false,
    })
    BuyBaitDropdown:OnChanged(updateBaitPrice)
    
    BuyBaitSection:AddButton({
        Title = "Purchase Bait",
        Callback = function()
            local ok, err = fireRemote(Events.BuyBait, BaitSelect)
            if ok then
                U.notify("Buy Bait", "Đã mua: " .. BaitSelect)
            else
                U.notify("Buy Bait", "Lỗi: " .. tostring(err))
            end
        end,
    })
end