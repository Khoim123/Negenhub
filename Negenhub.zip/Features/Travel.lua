-- Features/Travel.lua
-- Teleport Island, NPC, Secret Rod
return function(Shared)
    local S, U, Tabs = Shared.Services, Shared.Utils, Shared.Tabs
    local LocalPlayer = S.LocalPlayer
    
    local Island = nil
    local ISLAND_CFRAME = {
        ["Hòn Đảo Đầu Tiên/Đảo 1"] = CFrame.new(-246.299774, 5.562889, 34.007786),
        ["Hòn Đảo Tre/Đảo 2"]      = CFrame.new(-1237.534058, 6.762336, 7.125682),
        ["Hòn Đảo Tro Bụi/Đảo 3"]  = CFrame.new(54.566505, 6.762336, 1149.462646),
        ["Đảo Chủ Quyền/Đảo 4"]    = CFrame.new(-1236.228394, 6.762336, 1246.501831),
        ["Đảo Perch/Đảo 5"]        = CFrame.new(-58.784176, 9.276019, -1336.979248),
        ["Đảo Băng Giá/Đảo 6"]     = CFrame.new(-1346.217529, 9.275619, -1481.279297),
        ["Đảo Dừa/Đảo 7"]          = CFrame.new(1415.946411, 6.761940, -1521.731812),
        ["Đảo Hổ Phách/Đảo 8"]     = CFrame.new(1187.160278, 9.275619, 1392.009766),
        ["Đảo Chiến Trường/Đảo 9"] = CFrame.new(1394.835938, 9.275619, 227.497574),
        ["Đảo MistPeak/Đảo 10"]     = CFrame.new(2596.094727, 9.275619, -35.989719),
    }
    local ISLAND_NAMES = {
        "Hòn Đảo Đầu Tiên/Đảo 1", "Hòn Đảo Tre/Đảo 2", "Hòn Đảo Tro Bụi/Đảo 3",
        "Đảo Chủ Quyền/Đảo 4", "Đảo Perch/Đảo 5", "Đảo Băng Giá/Đảo 6",
        "Đảo Dừa/Đảo 7", "Đảo Hổ Phách/Đảo 8", "Đảo Chiến Trường/Đảo 9", "Đảo MistPeak/Đảo 10",
    }
    
    local IslandDropdown = Tabs.Travel:AddDropdownCanFind("IslandDropdown", {
        Title = "Island",
        Values = ISLAND_NAMES,
        Multi = false,
    })
    IslandDropdown:OnChanged(function(v)
        Island = nil
        if type(v) == "table" then
            for name, state in next, v do
                if state then Island = name; break end
            end
        elseif type(v) == "string" then
            Island = v
        end
    end)
    
    Tabs.Travel:AddButton({
        Title = "Teleport",
        Callback = function()
            if not Island then U.notify("Teleport", "Chưa chọn đảo!"); return end
            local target = ISLAND_CFRAME[Island]
            if not target then
                U.notify("Teleport", 'Không có tọa độ cho đảo: "' .. tostring(Island) .. '"')
                return
            end
            U.notify("Teleport", 'Đang dịch chuyển tới "' .. Island .. '"...', 2)
            local ok, err = U.teleport(target)
            if ok then
                U.notify("Teleport", 'Đã tới "' .. Island .. '"')
            else
                U.notify("Teleport", "Dịch chuyển thất bại: " .. tostring(err), 5)
            end
        end,
    })
    
    -- ==========================================
    -- NPC Teleport
    -- ==========================================
    local TELEPORT_OFFSET = Vector3.new(0, 3, 0)
    local NPC_LIST = {
        { Name = "Tang Thien Quoc", Path = {"NPC", "Function", "Tang Thien Quoc"}, },
        { Name = "Enzo", Path = {"NPC", "Boss", "Enzo"}, },
        { Name = "Giang Lao", Path = {"NPC","Function","Giang Lao"}, },
        { Name = "Ha Dieu De", Path = {"NPC","Function","Ha Dieu De"}, },
        { Name = "Lao Ngo", Path = {"NPC","Function","Lao Ngo"}, },
        { Name = "Sage Yijiu", Path = {"NPC","Function","Sage Yijiu"}, },
        { Name = "Bac Minh", Path = {"NPC","Function","Bac Minh"}, },
        { Name = "Nanjiang", Path = {"NPC","Function","Nanjiang"}, },
        { Name = "Sage Yijiu Learn Skill", Path = {"NPC","LearnSkill","Sage Yijiu"}, },
        { Name = "Ticket Quest Giver", Path = {"NPC","Function","Ticket Quest Giver"}, },
        { Name = "Taoist", Path = {"NPC","Function","Taoist"}, },
        { Name = "Spirit", Path = {"NPC","Spirit"}, },
    }
    
    local function getInstanceFromPath(pathList)
        local current = workspace
        for _, childName in ipairs(pathList) do
            local nextInstance = current:FindFirstChild(childName)
            if not nextInstance then return nil end
            current = nextInstance
        end
        return current
    end
    
    local function getTeleportPart(target)
        if not target then return nil end
        if target:IsA("BasePart") then return target end
        local rootPart = target:FindFirstChild("HumanoidRootPart", true)
        if rootPart and rootPart:IsA("BasePart") then return rootPart end
        if target:IsA("Model") and target.PrimaryPart then return target.PrimaryPart end
        return nil
    end
    
    local dropdownValues = {}
    local npcConfigByName = {}
    for _, npcConfig in ipairs(NPC_LIST) do
        table.insert(dropdownValues, npcConfig.Name)
        npcConfigByName[npcConfig.Name] = npcConfig
    end
    
    local npcselect = dropdownValues[1]
    local npcteleportSection = Tabs.Travel:AddSection("NPC Teleport")
    local npcteleportDropdown = npcteleportSection:AddDropdownCanFind("Dropdown", {
        Title = "NPC Select",
        Values = dropdownValues,
        Multi = false,
    })
    npcteleportDropdown:OnChanged(function(Value)
        npcselect = nil
        if type(Value) == "table" then
            for name, state in next, Value do
                if state then npcselect = name; break end
            end
        elseif type(Value) == "string" then
            npcselect = Value
        end
    end)
    
    npcteleportSection:AddButton({
        Title = "Teleport To NPC",
        Callback = function()
            if not npcselect then U.notify("Negen", "Chưa Chọn NPC"); return end
            local npcConfig = npcConfigByName[npcselect]
            if not npcConfig then
                U.notify("NPC Teleport", 'Không tìm thấy cấu hình NPC: "' .. tostring(npcselect) .. '"'); return
            end
            local targetPart
            if npcConfig.GetPart then
                targetPart = npcConfig.GetPart()
            elseif npcConfig.Path then
                local npcObject = getInstanceFromPath(npcConfig.Path)
                targetPart = getTeleportPart(npcObject)
            end
            if not targetPart then
                U.notify("NPC Teleport", 'Không tìm thấy NPC "' .. tostring(npcselect) .. '" trong workspace (có thể chưa spawn hoặc path đã đổi)', 5)
                return
            end
            U.notify("NPC Teleport", 'Đang dịch chuyển tới "' .. npcselect .. '"...', 2)
            local ok, err = U.teleport(targetPart.CFrame + TELEPORT_OFFSET)
            if ok then
                U.notify("NPC Teleport", 'Đã tới "' .. npcselect .. '"')
            else
                U.notify("NPC Teleport", "Dịch chuyển thất bại: " .. tostring(err), 5)
            end
        end,
    })
    
    -- ==========================================
    -- Secret Rod Teleport
    -- ==========================================
    local secretrodSection = Tabs.Travel:AddSection("Secret Rod Teleport")
    local ROD_NAMES = {
        "Anchorbound Rod", "Ascendant Bamboo Rod", "Blazeshark Rod",
        "Demonic Rod", "Kraken Rod", "Lifebloom Rod",
    }
    
    local function findRodHandle(rodName)
        local secretRodFolder = workspace:FindFirstChild("SecretRod")
        if not secretRodFolder then return nil end
        local rodModel = secretRodFolder:FindFirstChild(rodName)
        if not rodModel then return nil end
        local handle = rodModel:FindFirstChild("Handle")
        if handle and handle:IsA("BasePart") then return handle end
        return getTeleportPart(rodModel)
    end
    
    local selectedRod = ROD_NAMES[1]
    local secretrodDropdown = secretrodSection:AddDropdownCanFind("SecretRodDropdown", {
        Title = "Select Rod",
        Values = ROD_NAMES,
        Multi = false,
    })
    secretrodDropdown:OnChanged(function(value)
        selectedRod = nil
        if type(value) == "table" then
            for name, state in next, value do
                if state then selectedRod = name; break end
            end
        elseif type(value) == "string" then
            selectedRod = value
        end
    end)
    
    secretrodSection:AddButton({
        Title = "Teleport To Rod",
        Callback = function()
            if not selectedRod then U.notify("Rod Teleport", "Chưa chọn Rod!"); return end
            local handle = findRodHandle(selectedRod)
            if not handle then
                U.notify("Rod Teleport", 'Không tìm thấy Rod: ' .. selectedRod .. '\n(Kiểm tra workspace.SecretRod có tồn tại không?)', 5)
                return
            end
            U.notify("Rod Teleport", 'Đang dịch chuyển tới "' .. selectedRod .. '"...', 2)
            local ok, err = U.teleport(handle.CFrame + TELEPORT_OFFSET)
            if ok then
                U.notify("Rod Teleport", 'Đã tới "' .. selectedRod .. '"')
            else
                U.notify("Rod Teleport", "Dịch chuyển thất bại: " .. tostring(err), 5)
            end
        end,
    })
end