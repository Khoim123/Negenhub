-- Features/AutoSkill.lua
-- Auto dùng skill khi hết cooldown
return function(Shared)
    local S, U, Tabs = Shared.Services, Shared.Utils, Shared.Tabs
    local Events = S.Events
    local LocalPlayer = S.LocalPlayer
    
    local skillSelects = { First = nil, Second = nil, Third = nil, Last = nil }
    local autoSkillEnabled = false
    local UseSkillEvent = Events.UseSkill
    local SKILL_SLOTS = { "First", "Second", "Third", "Last" }
    local SKILL_KEYS  = { "Z", "X", "C", "V" }
    
    local function getSkillCooldown(skillKey)
        local gui = LocalPlayer.PlayerGui:FindFirstChild("MainGui")
        local node = gui and gui:FindFirstChild("Fishing")
        node = node and node:FindFirstChild("SkillButton")
        node = node and node:FindFirstChild("Frame")
        node = node and node:FindFirstChild(skillKey)
        local cd = node and node:FindFirstChild("CD")
        if not cd then return 0 end
        local text = cd.ContentText
        local num = text and text ~= "" and tonumber(text)
        return (num and num > 0) and num or 0
    end
    
    local function getSkillOrder()
        local list = {}
        for _, slot in ipairs(SKILL_SLOTS) do
            local key = skillSelects[slot]
            if key and key ~= "" then table.insert(list, key) end
        end
        return list
    end
    
    local function isFishing()
        local char = LocalPlayer.Character
        if char and char:GetAttribute("Fishing") then return true end
        local gui = LocalPlayer.PlayerGui:FindFirstChild("MainGui")
        local fishing = gui and gui:FindFirstChild("Fishing")
        if fishing and fishing.Visible then return true end
        return false
    end
    
    local function autoSkillLoop()
        while autoSkillEnabled do
            if not isFishing() then
                task.wait(0.5)
                continue
            end
            
            local skills = getSkillOrder()
            if #skills == 0 then task.wait(0.5); continue end
            
            local usedAny = false
            for _, skillKey in ipairs(skills) do
                if getSkillCooldown(skillKey) <= 0 then
                    UseSkillEvent:FireServer(skillKey)
                    usedAny = true
                    task.wait(0.15)
                    break
                end
            end
            if not usedAny then task.wait(0.1) end
        end
    end
    
    local AutoSkill = Tabs.Main:AddSection("Auto Skill")
    for _, slot in ipairs(SKILL_SLOTS) do
        local dd = AutoSkill:AddDropdown(slot .. " Skill", {
            Title = slot .. " Skill Select",
            Values = SKILL_KEYS,
        })
        dd:OnChanged(function(v) skillSelects[slot] = v end)
    end
    
    AutoSkill:AddToggle("Auto Skill Toggle", {
        Title = "Auto Skill",
        Default = false,
        Callback = function(state)
            autoSkillEnabled = state
            if state then
                task.spawn(autoSkillLoop)
                U.notify("Auto Skill", "Đã BẬT! Tự dùng skill khi hết CD")
            else
                U.notify("Auto Skill", "Đã TẮT")
            end
        end,
    })
end