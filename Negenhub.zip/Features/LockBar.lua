-- Features/LockBar.lua
-- Lock Bar giữa BarFrame khi câu cá
return function(Shared)
    local S, U, Tabs, Options = Shared.Services, Shared.Utils, Shared.Tabs, Shared.Options
    local RunService = S.RunService
    local LocalPlayer = S.LocalPlayer
    
    local lockEnabled = false
    local renderConnection = nil
    local disabledScripts = {}
    local barWatchConnection = nil
    
    Tabs.Main:AddToggle("LockBarToggle", {
        Title = "Lock Bar giữa BarFrame",
        Default = false,
        Callback = function(state)
            lockEnabled = state
            U.notify("Bar Lock", state and "Đã BẬT giữ Bar" or "Đã TẮT giữ Bar")
        end,
    })
    
    local function getBarFrame()
        local playerGui = LocalPlayer:FindFirstChild("PlayerGui")
        local mainGui = playerGui and playerGui:FindFirstChild("MainGui")
        local fishing = mainGui and mainGui:FindFirstChild("Fishing")
        return fishing and fishing:FindFirstChild("BarFrame")
    end
    
    local function getBar()
        local barFrame = getBarFrame()
        return barFrame and barFrame:FindFirstChild("Bar")
    end
    
    local BAR_ANCHOR = Vector2.new(0.5, 0.5)
    local BAR_POS    = UDim2.new(0.5, 0, 0.5, 0)
    
    local mt = getrawmetatable(game)
    local oldNewindex = mt.__newindex
    setreadonly(mt, false)
    
    mt.__newindex = newcclosure(function(self, prop, value)
        if lockEnabled and not checkcaller()
            and self:IsA("GuiObject") and self.Name == "Bar"
            and (prop == "Position" or prop == "AnchorPoint") then
            return
        end
        return oldNewindex(self, prop, value)
    end)
    
    setreadonly(mt, true)
    
    local function forceCenter(bar)
        pcall(function()
            bar.AnchorPoint = BAR_ANCHOR
            bar.Position    = BAR_POS
            bar.Rotation    = 0
        end)
    end
    
    local function lockBar()
        if not lockEnabled then return end
        local bar = getBar()
        if bar then forceCenter(bar) end
    end
    
    local function disableGameBarScripts()
        local barFrame = getBarFrame()
        local fishing = barFrame and barFrame.Parent
        if not fishing then return end
        for _, obj in ipairs(fishing:GetDescendants()) do
            if obj:IsA("LocalScript") and not table.find(disabledScripts, obj) then
                pcall(function()
                    obj.Enabled = false
                    table.insert(disabledScripts, obj)
                end)
            end
        end
    end
    
    local function restoreGameBarScripts()
        for _, obj in ipairs(disabledScripts) do
            pcall(function() obj.Enabled = true end)
        end
        table.clear(disabledScripts)
    end
    
    local function watchBarFrame()
        if barWatchConnection then barWatchConnection:Disconnect() end
        local barFrame = getBarFrame()
        if not barFrame then return end
        barWatchConnection = barFrame.ChildAdded:Connect(function(child)
            if lockEnabled and child.Name == "Bar" then
                task.wait()
                forceCenter(child)
                disableGameBarScripts()
            end
        end)
    end
    
    local function applyConnection()
        if renderConnection then renderConnection:Disconnect(); renderConnection = nil end
        if not lockEnabled then
            restoreGameBarScripts()
            return
        end
        disableGameBarScripts()
        watchBarFrame()
        renderConnection = RunService.RenderStepped:Connect(lockBar)
    end
    
    Options.LockBarToggle:OnChanged(function()
        lockEnabled = Options.LockBarToggle.Value
        applyConnection()
    end)
end