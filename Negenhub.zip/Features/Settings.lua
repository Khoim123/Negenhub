-- Features/Settings.lua
-- Full Bright, Fix Lag, Speed Hack, Fly GUI, Anti AFK
return function(Shared)
    local S, U, GuiParent, Tabs = Shared.Services, Shared.Utils, Shared.GuiParent, Shared.Tabs
    local Lighting = S.Lighting
    local RunService = S.RunService
    local UserInputService = S.UserInputService
    local TweenService = S.TweenService
    local LocalPlayer = S.LocalPlayer
    local VirtualUser = S.VirtualUser
    
    -- ==========================================
    -- Full Bright
    -- ==========================================
    local fullBrightEnabled = false
    local fullBrightLoop = nil
    local fullBrightPropConns = {}
    local originalLighting = {}
    
    local FB_VALUES = {
        Ambient                  = Color3.fromRGB(255, 255, 255),
        OutdoorAmbient           = Color3.fromRGB(255, 255, 255),
        Brightness               = 2,
        ClockTime                = 14,
        FogEnd                   = 1e6,
        FogStart                 = 0,
        GlobalShadows            = false,
        EnvironmentDiffuseScale  = 0,
        EnvironmentSpecularScale = 0,
    }
    local FB_PROPS = {}
    for k in pairs(FB_VALUES) do table.insert(FB_PROPS, k) end
    
    local function applyFullBright()
        for prop, val in pairs(FB_VALUES) do pcall(function() Lighting[prop] = val end) end
    end
    
    local function setFullBrightLocks(attach)
        for _, c in ipairs(fullBrightPropConns) do c:Disconnect() end
        table.clear(fullBrightPropConns)
        if not attach then return end
        for _, prop in ipairs(FB_PROPS) do
            table.insert(fullBrightPropConns,
                Lighting:GetPropertyChangedSignal(prop):Connect(function()
                    if fullBrightEnabled then
                        pcall(function() Lighting[prop] = FB_VALUES[prop] end)
                    end
                end)
            )
        end
    end
    
    Tabs.Settings:AddToggle("FullBrightToggle", {
        Title = "Full Bright",
        Default = false,
        Callback = function(state)
            fullBrightEnabled = state
            if state then
                for _, prop in ipairs(FB_PROPS) do originalLighting[prop] = Lighting[prop] end
                applyFullBright()
                setFullBrightLocks(true)
                fullBrightLoop = task.spawn(function()
                    while fullBrightEnabled do applyFullBright(); task.wait(1) end
                end)
                U.notify("Full Bright", "Đã BẬT + khoá!")
            else
                setFullBrightLocks(false)
                for prop, val in pairs(originalLighting) do pcall(function() Lighting[prop] = val end) end
                table.clear(originalLighting)
                U.notify("Full Bright", "Đã TẮT, khôi phục")
            end
        end,
    })
    
    -- ==========================================
    -- Fix Lag
    -- ==========================================
    local lagFixEnabled = false
    
    local function applyLagFix()
        settings().Rendering.QualityLevel = 1
        local terrain = workspace:FindFirstChild("Terrain")
        if terrain then
            terrain.WaterReflectance = 0
            terrain.WaterWaveSize    = 0
            terrain.WaterWaveSpeed   = 0
        end
        for _, obj in ipairs(workspace:GetDescendants()) do
            if obj:IsA("ParticleEmitter") then obj.Rate = 0
            elseif obj:IsA("Trail")       then obj.Enabled = false end
        end
        local hrp = U.getHRP(LocalPlayer)
        if hrp then
            for _, obj in ipairs(workspace:GetDescendants()) do
                if obj:IsA("Part") and (obj.Position - hrp.Position).Magnitude > 500 then
                    obj.LocalTransparencyModifier = 1
                end
            end
        end
    end
    
    local function revertLagFix()
        settings().Rendering.QualityLevel = 3
        local terrain = workspace:FindFirstChild("Terrain")
        if terrain then
            terrain.WaterReflectance = 0.3
            terrain.WaterWaveSize    = 0.2
            terrain.WaterWaveSpeed   = 20
        end
        for _, obj in ipairs(workspace:GetDescendants()) do
            if obj:IsA("ParticleEmitter") then obj.Rate = 16
            elseif obj:IsA("Trail")       then obj.Enabled = true end
        end
    end
    
    Tabs.Settings:AddToggle("FixLagToggle", {
        Title = "Fix Lag",
        Default = false,
        Callback = function(state)
            lagFixEnabled = state
            if state then
                applyLagFix()
                task.spawn(function() while lagFixEnabled do applyLagFix(); task.wait(5) end end)
                U.notify("Fix Lag", "Đã BẬT!")
            else
                revertLagFix()
                U.notify("Fix Lag", "Đã TẮT")
            end
        end,
    })
    
    -- ==========================================
    -- Speed Hack
    -- ==========================================
    local SpeedSection = Tabs.Settings:AddSection("Speed Hack")
    local speedHackEnabled = false
    local speedHackValue = 16
    local speedHackPropConns = {}
    
    local function applySpeedHack()
        local hum = U.getHum(LocalPlayer)
        if hum and hum.WalkSpeed ~= speedHackValue then hum.WalkSpeed = speedHackValue end
    end
    
    local function setSpeedLocks(attach)
        for _, c in ipairs(speedHackPropConns) do c:Disconnect() end
        table.clear(speedHackPropConns)
        if not attach then return end
        local hum = U.getHum(LocalPlayer)
        if not hum then return end
        table.insert(speedHackPropConns,
            hum:GetPropertyChangedSignal("WalkSpeed"):Connect(function()
                if speedHackEnabled and hum.WalkSpeed ~= speedHackValue then
                    hum.WalkSpeed = speedHackValue
                end
            end)
        )
    end
    
    SpeedSection:AddInput("SpeedInput", {
        Title = "Walk Speed",
        Default = "16", Placeholder = "16",
        Numeric = true, Finished = true,
        Callback = function(value)
            local num = tonumber(value)
            if num then
                speedHackValue = math.clamp(math.floor(num), 1, 500)
                if speedHackEnabled then applySpeedHack() end
                U.notify("Speed", "WalkSpeed → " .. speedHackValue, 2)
            end
        end,
    })
    
    SpeedSection:AddToggle("SpeedHackToggle", {
        Title = "Speed Hack",
        Default = false,
        Callback = function(state)
            speedHackEnabled = state
            if state then
                applySpeedHack()
                setSpeedLocks(true)
                task.spawn(function()
                    while speedHackEnabled do
                        applySpeedHack()
                        if #speedHackPropConns == 0 then setSpeedLocks(true) end
                        task.wait(1)
                    end
                end)
                U.notify("Speed Hack", "BẬT! WalkSpeed = " .. speedHackValue)
            else
                setSpeedLocks(false)
                local hum = U.getHum(LocalPlayer)
                if hum then hum.WalkSpeed = 16 end
                U.notify("Speed Hack", "TẮT! Reset về 16")
            end
        end,
    })
    
    LocalPlayer.CharacterAdded:Connect(function()
        task.wait(0.5)
        if speedHackEnabled then applySpeedHack(); setSpeedLocks(true) end
    end)
    
    -- ==========================================
    -- Fly GUI
    -- ==========================================
    local FLY_GUI_URL = "https://raw.githubusercontent.com/Khoim123/Khoim123/refs/heads/main/FlyGui.lua"
    local FlyGUI = loadstring(game:HttpGet(FLY_GUI_URL))()
    FlyGUI.Init({
        LocalPlayer      = LocalPlayer,
        RunService       = RunService,
        UserInputService = UserInputService,
        TweenService     = TweenService,
        parentGuiSafe    = GuiParent.parentGuiSafe,
        notify           = U.notify,
        setToggle        = function(flagName, value) U.setToggle(Shared.Options, flagName, value) end,
        getHRP           = U.getHRP,
        getHum           = U.getHum,
    })
    
    Tabs.Settings:AddToggle("FlyGuiToggle", {
        Title = "Fly GUI",
        Default = false,
        Callback = function(state)
            if state then
                FlyGUI.Create()
                U.notify("Fly GUI", "Đã mở Fly GUI!")
            else
                FlyGUI.Destroy()
                U.notify("Fly GUI", "Đã đóng Fly GUI")
            end
        end,
    })
    
    LocalPlayer.CharacterAdded:Connect(function(char)
        task.wait(0.7)
        FlyGUI.OnRespawn()
    end)
    
    -- ==========================================
    -- Anti AFK
    -- ==========================================
    local antiAfkEnabled = true
    
    local function setupAntiAfk()
        LocalPlayer.Idled:Connect(function()
            if antiAfkEnabled then
                VirtualUser:CaptureController()
                VirtualUser:ClickButton2(Vector2.new())
            end
        end)
    end
    setupAntiAfk()
    
    Tabs.Settings:AddToggle("AntiAfkToggle", {
        Title = "Anti AFK",
        Default = true,
        Callback = function(state)
            antiAfkEnabled = state
            U.notify("Anti AFK", state and "Đã BẬT! Không bị kick" or "Đã TẮT! Có thể bị kick AFK")
        end,
    })
end