-- Features/Players.lua
-- ESP, Follow, View, Teleport to Player
return function(Shared)
    local S, U, Tabs, Options = Shared.Services, Shared.Utils, Shared.Tabs, Shared.Options
    local Players = S.Players
    local RunService = S.RunService
    local LocalPlayer = S.LocalPlayer
    
    local PlayersSection = Tabs.Others:AddSection("Player")
    local selectedPlayer = nil
    local selectedPlayerKey = nil
    local playerLookup = {}
    local followEnabled = false
    local followConnection = nil
    local viewEnabled = false
    local originalCameraSubject = nil
    local espEnabled = false
    local espHighlights = {}
    
    local function isPlayerValid(p) return p ~= nil and p.Parent == Players end
    
    local function buildPlayerKey(p)
        local dn, un = p.DisplayName, p.Name
        if not dn or dn == "" then dn = un end
        if not un or un == "" then un = "?" end
        local base = string.format("%s (@%s)", dn, un)
        if not playerLookup[base] then return base end
        local i = 2
        while playerLookup[base .. "  #" .. i] do i += 1 end
        return base .. "  #" .. i
    end
    
    local function buildPlayerList()
        playerLookup = {}
        local keys = {}
        for _, p in ipairs(Players:GetPlayers()) do
            if p ~= LocalPlayer then
                local key = buildPlayerKey(p)
                playerLookup[key] = p
                table.insert(keys, key)
            end
        end
        table.sort(keys)
        return keys
    end
    
    local PlayerDropdown
    local function refreshPlayerDropdown()
        local keys = buildPlayerList()
        if not pcall(function() PlayerDropdown:SetValues(keys) end) then
            pcall(function() PlayerDropdown:Set(keys) end)
        end
        if selectedPlayer and (not isPlayerValid(selectedPlayer)) then
            selectedPlayer, selectedPlayerKey = nil, nil
        elseif selectedPlayer then
            local stillExists = false
            for _, k in ipairs(keys) do
                if playerLookup[k] == selectedPlayer then
                    stillExists = true
                    selectedPlayerKey = k
                    break
                end
            end
            if not stillExists then selectedPlayer, selectedPlayerKey = nil, nil end
        end
        return #keys
    end
    
    PlayerDropdown = PlayersSection:AddDropdown("PlayerDropdown", {
        Title = "Select Player",
        Values = buildPlayerList(),
        Multi = false,
    })
    
    PlayerDropdown:OnChanged(function(value)
        selectedPlayer = playerLookup[value]
        selectedPlayerKey = value
        if selectedPlayer then
            U.notify("Player", "Đã chọn: " .. selectedPlayer.DisplayName, 2)
        end
    end)
    
    PlayersSection:AddButton({
        Title = "Refresh Player",
        Callback = function()
            local count = refreshPlayerDropdown()
            U.notify("Player", "Đã làm mới! Tìm thấy " .. count .. " player khác.")
        end,
    })
    
    PlayersSection:AddButton({
        Title = "Teleport To Player",
        Callback = function()
            if not selectedPlayer then U.notify("Player", "Vui lòng chọn player trước!"); return end
            if not isPlayerValid(selectedPlayer) then
                U.notify("Player", selectedPlayer.Name .. " đã rời game!")
                refreshPlayerDropdown()
                return
            end
            local targetHRP = U.getHRP(selectedPlayer)
            if not targetHRP then
                U.notify("Player", selectedPlayer.Name .. " chưa spawn hoặc không có HRP!")
                return
            end
            U.teleport(targetHRP.CFrame * CFrame.new(0, 3, 3))
            U.notify("Player", "Đã teleport tới " .. selectedPlayer.DisplayName)
        end,
    })
    
    -- ==========================================
    -- Follow Player
    -- ==========================================
    local function stopFollow()
        followEnabled = false
        if followConnection then followConnection:Disconnect(); followConnection = nil end
        local myHum = U.getHum(LocalPlayer)
        if myHum then myHum.PlatformStand = false end
    end
    
    PlayersSection:AddToggle("FollowPlayerToggle", {
        Title = "Follow Player",
        Default = false,
        Callback = function(state)
            followEnabled = state
            if state then
                if not selectedPlayer or not isPlayerValid(selectedPlayer) then
                    followEnabled = false
                    U.setToggle(Options, "FollowPlayerToggle", false)
                    U.notify("Follow", "Chưa chọn player! Hãy chọn player trong dropdown trước.")
                    return
                end
                stopFollow()
                followEnabled = true
                local notifiedMissing = false
                followConnection = RunService.Heartbeat:Connect(function()
                    if not followEnabled then return end
                    if not selectedPlayer or not isPlayerValid(selectedPlayer) then
                        stopFollow()
                        U.setToggle(Options, "FollowPlayerToggle", false)
                        U.notify("Follow", "Player không còn hợp lệ, đã dừng follow!")
                        return
                    end
                    local targetHRP = U.getHRP(selectedPlayer)
                    local myChar = LocalPlayer.Character
                    local myHRP  = myChar and myChar:FindFirstChild("HumanoidRootPart")
                    if not targetHRP then
                        if not notifiedMissing then
                            notifiedMissing = true
                            U.notify("Follow", selectedPlayer.DisplayName .. " chưa spawn, đang chờ...")
                        end
                        return
                    else notifiedMissing = false end
                    if not myHRP then return end
                    myHRP.CFrame = targetHRP.CFrame * CFrame.new(0, 0, 4)
                end)
                U.notify("Follow", "Đang follow " .. (selectedPlayer and selectedPlayer.DisplayName or "..."))
            else
                stopFollow()
                U.notify("Follow", "Đã dừng follow!")
            end
        end,
    })
    
    -- ==========================================
    -- View Player
    -- ==========================================
    local function restoreCamera()
        local camera = workspace.CurrentCamera
        if originalCameraSubject and originalCameraSubject.Parent then
            camera.CameraSubject = originalCameraSubject
        else
            local myHum = U.getHum(LocalPlayer)
            if myHum then camera.CameraSubject = myHum end
        end
        originalCameraSubject = nil
    end
    
    PlayersSection:AddToggle("ViewPlayerToggle", {
        Title = "View Player",
        Default = false,
        Callback = function(state)
            viewEnabled = state
            if state then
                if not selectedPlayer or not isPlayerValid(selectedPlayer) then
                    viewEnabled = false
                    U.setToggle(Options, "ViewPlayerToggle", false)
                    U.notify("View", "Vui lòng chọn player trước!")
                    return
                end
                local targetHum = U.getHum(selectedPlayer)
                if not targetHum then
                    viewEnabled = false
                    U.setToggle(Options, "ViewPlayerToggle", false)
                    U.notify("View", "Player chưa spawn!")
                    return
                end
                originalCameraSubject = workspace.CurrentCamera.CameraSubject
                workspace.CurrentCamera.CameraSubject = targetHum
                U.notify("View", "Đang xem " .. selectedPlayer.DisplayName)
            else
                restoreCamera()
                U.notify("View", "Đã dừng xem!")
            end
        end,
    })
    
    -- ==========================================
    -- ESP / Highlight Player
    -- ==========================================
    local function createEspForPlayer(p)
        if p == LocalPlayer or espHighlights[p] then return end
        local char = p.Character
        if not char then return end
        espHighlights[p] = U.new("Highlight", {
            Name                = "NegenESP",
            Adornee             = char,
            FillColor           = Color3.fromRGB(0, 255, 0),
            FillTransparency    = 1,
            OutlineColor        = Color3.fromRGB(0, 255, 0),
            OutlineTransparency = 0,
            DepthMode           = Enum.HighlightDepthMode.AlwaysOnTop,
        }, char)
    end
    
    local function removeEspForPlayer(p)
        if espHighlights[p] then
            pcall(function() espHighlights[p]:Destroy() end)
            espHighlights[p] = nil
        end
    end
    
    PlayersSection:AddToggle("EspPlayerToggle", {
        Title = "ESP / Highlight Player",
        Default = false,
        Callback = function(state)
            espEnabled = state
            if state then
                for _, p in ipairs(Players:GetPlayers()) do
                    if p ~= LocalPlayer then createEspForPlayer(p) end
                end
                U.notify("ESP", "Đã BẬT ESP cho tất cả player!")
            else
                for p in pairs(espHighlights) do removeEspForPlayer(p) end
                U.notify("ESP", "Đã TẮT ESP!")
            end
        end,
    })
    
    local function setupEspCharListener(p)
        if p == LocalPlayer then return end
        p.CharacterAdded:Connect(function()
            task.wait(0.5)
            if espEnabled then removeEspForPlayer(p); createEspForPlayer(p) end
        end)
        p.CharacterRemoving:Connect(function() removeEspForPlayer(p) end)
    end
    
    Players.PlayerAdded:Connect(function(player)
        task.wait(1)
        refreshPlayerDropdown()
        setupEspCharListener(player)
    end)
    
    Players.PlayerRemoving:Connect(function(leaving)
        if selectedPlayer == leaving then
            selectedPlayer, selectedPlayerKey = nil, nil
            if followEnabled then
                stopFollow()
                U.setToggle(Options, "FollowPlayerToggle", false)
            end
            if viewEnabled then
                viewEnabled = false
                restoreCamera()
                U.setToggle(Options, "ViewPlayerToggle", false)
            end
        end
        removeEspForPlayer(leaving)
        task.wait(0.1)
        refreshPlayerDropdown()
    end)
    
    for _, p in ipairs(Players:GetPlayers()) do setupEspCharListener(p) end
    task.spawn(function() task.wait(1); refreshPlayerDropdown() end)
end