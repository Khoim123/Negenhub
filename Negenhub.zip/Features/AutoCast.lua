-- Features/AutoCast.lua
-- Auto câu cá + Method Auto Fishing + Saved Spots
return function(Shared)
    local S, U, FileIO, Tabs = Shared.Services, Shared.Utils, Shared.FileIO, Shared.Tabs
    local Events = S.Events
    local LocalPlayer = S.LocalPlayer
    
    local autoCastEnabled = false
    local selectedMethod = "Anywhere"
    local savedSpots = {}
    local selectedSpotName = nil
    local SpotFishingDropdown = nil
    local wasFishing = false
    
    -- ==========================================
    -- Helpers
    -- ==========================================
    local function isFishing()
        local char = LocalPlayer.Character
        if char and char:GetAttribute("Fishing") then return true end
        local gui = LocalPlayer.PlayerGui:FindFirstChild("MainGui")
        local fishing = gui and gui:FindFirstChild("Fishing")
        if fishing and fishing.Visible then return true end
        return false
    end
    
    local function hasStickEquipped()
        local charInWorkspace = workspace:FindFirstChild(LocalPlayer.Name)
        if not charInWorkspace then return false end
        local toolFolder = charInWorkspace:FindFirstChild("Tool")
        if not toolFolder then return false end
        return toolFolder:FindFirstChild("Stick") ~= nil
    end
    
    local function equipRod()
        pcall(function() Events.ToggleHotbar:InvokeServer("1", nil) end)
    end
    
    -- ==========================================
    -- Auto Cast Loop
    -- ==========================================
    local function autoCastLoop()
        while autoCastEnabled do
            if not isFishing() then
                if not hasStickEquipped() then
                    equipRod()
                    task.wait(0.5)
                    continue
                end
                
                if selectedMethod == "Saved Spot" then
                    if selectedSpotName and savedSpots[selectedSpotName] then
                        U.teleport(savedSpots[selectedSpotName])
                        task.wait(0.3)
                    else
                        U.notify("Auto Cast", "Chưa chọn Spot hoặc Spot không tồn tại!", 3)
                        task.wait(2)
                        continue
                    end
                end
                pcall(function() Events.Fishing:FireServer() end)
            end
            task.wait(1)
        end
    end
    
    Tabs.Main:AddToggle("AutoCastToggle", {
        Title = "Auto Cast",
        Default = false,
        Callback = function(state)
            autoCastEnabled = state
            if state then
                task.spawn(autoCastLoop)
                U.notify("Auto Cast", "Đã BẬT! Tự ném câu khi rảnh")
            else
                U.notify("Auto Cast", "Đã TẮT")
            end
        end,
    })
    
    -- ==========================================
    -- Method Auto Fishing
    -- ==========================================
    local function refreshSpotDropdown()
        local names = {}
        for name, _ in pairs(savedSpots) do table.insert(names, name) end
        table.sort(names)
        if SpotFishingDropdown then
            local ok = pcall(function() SpotFishingDropdown:SetValues(names) end)
            if not ok then pcall(function() SpotFishingDropdown:Set(names) end) end
        end
        if selectedSpotName and not savedSpots[selectedSpotName] then
            selectedSpotName = nil
        end
        return names
    end
    
    local methodautofishing = Tabs.Main:AddSection("Method Auto Fishing")
    
    local selectmethodspotfishing = methodautofishing:AddDropdown("Select Method Spot Dropdown", {
        Title = "Select Method Spot Fishing",
        Values = {"Anywhere", "Saved Spot"},
        Default = 1,
    })
    selectmethodspotfishing:OnChanged(function(Value)
        selectedMethod = Value
        U.notify("Method", "Chế độ: " .. Value, 2)
    end)
    
    SpotFishingDropdown = methodautofishing:AddDropdown("Spot Fishing Dropdown", {
        Title = "Saved Spot Select",
        Values = {},
    })
    SpotFishingDropdown:OnChanged(function(Value)
        selectedSpotName = Value
    end)
    
    task.spawn(function()
        FileIO.loadSavedSpots(savedSpots, U.notify)
        refreshSpotDropdown()
    end)
    
    local NameSpotFishingInput = methodautofishing:AddInput("Name Spot Fishing Input", {
        Title = "Name Spot Fishing",
        Placeholder = "Nhập tên spot...",
        Numeric = false,
        Finished = false,
        Callback = function(Value) end,
    })
    
    local function getSpotNameInput()
        local val = NameSpotFishingInput.Value or ""
        return val:match("^%s*(.-)%s*$")
    end
    
    methodautofishing:AddButton({
        Title = "Save Spot",
        Callback = function()
            local name = getSpotNameInput()
            if name == "" then
                U.notify("Save Spot", "Vui lòng nhập tên spot trước!", 3)
                return
            end
            local hrp = U.getHRP(LocalPlayer)
            if not hrp then
                U.notify("Save Spot", "Character chưa spawn, không thể lưu vị trí!", 3)
                return
            end
            savedSpots[name] = hrp.CFrame
            refreshSpotDropdown()
            selectedSpotName = name
            
            local persistOk, persistErr, usedPath = FileIO.persistSavedSpots(savedSpots)
            local look = hrp.CFrame.LookVector
            local diskMsg
            if persistOk then
                local extra = (usedPath and ("\nPath: " .. usedPath)) or ""
                if persistErr then
                    diskMsg = "\n[OK] Lưu disk (" .. persistErr .. ")" .. extra
                else
                    diskMsg = "\n[OK] Lưu disk OK" .. extra
                end
            else
                diskMsg = "\n[LOI] Luu disk: " .. tostring(persistErr or "không rõ")
            end
            U.notify("Save Spot", string.format(
                'Đã lưu "%s"\nVị trí: (%.1f, %.1f, %.1f)\nHướng quay (Look): (%.2f, %.2f, %.2f)%s',
                name, hrp.CFrame.X, hrp.CFrame.Y, hrp.CFrame.Z, look.X, look.Y, look.Z, diskMsg
            ), 7)
        end,
    })
    
    methodautofishing:AddButton({
        Title = "Delete Spot",
        Callback = function()
            if not selectedSpotName or not savedSpots[selectedSpotName] then
                U.notify("Delete Spot", "Chưa chọn spot để xoá!", 3)
                return
            end
            local name = selectedSpotName
            savedSpots[name] = nil
            selectedSpotName = nil
            refreshSpotDropdown()
            FileIO.persistSavedSpots(savedSpots)
            U.notify("Delete Spot", string.format('Đã xoá spot "%s"', name), 3)
        end,
    })
    
    methodautofishing:AddButton({
        Title = "Teleport To Spot",
        Callback = function()
            if not selectedSpotName or not savedSpots[selectedSpotName] then
                U.notify("Teleport Spot", "Chưa chọn spot để teleport!", 3)
                return
            end
            U.teleport(savedSpots[selectedSpotName])
            U.notify("Teleport Spot", string.format('Đã teleport tới "%s"', selectedSpotName), 3)
        end,
    })
    
    -- Fishing-state monitor
    task.spawn(function()
        while true do
            local okNow, nowFishing = pcall(isFishing)
            if not okNow then nowFishing = false end
            if not LocalPlayer.Character then
                wasFishing = false
            else
                if wasFishing and not nowFishing then
                    if selectedMethod == "Saved Spot"
                        and selectedSpotName
                        and savedSpots[selectedSpotName] then
                        task.wait(0.25)
                        if LocalPlayer.Character then
                            U.teleport(savedSpots[selectedSpotName])
                        end
                    end
                end
                wasFishing = nowFishing
            end
            task.wait(0.3)
        end
    end)
end