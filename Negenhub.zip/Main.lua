-- Main.lua
-- Entry point: load tất cả modules song song
local BASE_URL = "https://raw.githubusercontent.com/Khoim123/NegenHub/main/"  -- ← Đổi URL repo của bạn

-- Helper load file với cache
local function loadModule(path)
    local url = BASE_URL .. path .. "?t=" .. os.time()
    local src = game:HttpGet(url)
    local fn, err = loadstring(src, path)
    if not fn then error("Load thất bại " .. path .. ": " .. tostring(err)) end
    return fn()
end

-- ==========================================
-- Load core libraries (cần chạy trước)
-- ==========================================
local Services  = loadModule("Lib/Services")()
local Utils     = loadModule("Lib/Utils")(Services)
local GuiParent = loadModule("Lib/GuiParent")(Services, Utils)
local FileIO    = loadModule("Lib/FileIO")(Services)

-- ==========================================
-- Load UI (Fluent + Window + Tabs)
-- ==========================================
local UI = loadModule("UI/Window")(Services, Utils, GuiParent)
local Fluent, Window, Tabs, Options, SaveManager, InterfaceManager =
    UI.Fluent, UI.Window, UI.Tabs, UI.Options, UI.SaveManager, UI.InterfaceManager

-- Shared state truyền vào các module
local Shared = {
    Services  = Services,
    Utils     = Utils,
    GuiParent = GuiParent,
    FileIO    = FileIO,
    Fluent    = Fluent,
    Window    = Window,
    Tabs      = Tabs,
    Options   = Options,
    SaveManager      = SaveManager,
    InterfaceManager = InterfaceManager,
}

-- ==========================================
-- Load features song song (nhanh hơn nhiều)
-- ==========================================
local features = {
    "Features/LockBar",
    "Features/AutoCast",
    "Features/AutoSkill",
    "Features/Shop",
    "Features/Travel",
    "Features/Players",
    "Features/Settings",
    "UI/MobileToggle",
}

for _, path in ipairs(features) do
    task.spawn(function()
        local ok, fn = pcall(loadModule, path)
        if ok and type(fn) == "function" then
            local ok2, err = pcall(fn, Shared)
            if not ok2 then
                warn("[NegenHub] Module lỗi: " .. path .. " → " .. tostring(err))
            end
        else
            warn("[NegenHub] Load module thất bại: " .. path)
        end
    end)
end

-- ==========================================
-- Finalize
-- ==========================================
Window:SelectTab(1)
Utils.notify("Negen Hub", "Đã load xong! Bật toggle để sử dụng.", 5)

SaveManager:BuildConfigSection(Tabs.Settings)
InterfaceManager:BuildInterfaceSection(Tabs.Settings)
task.spawn(function() SaveManager:LoadAutoloadConfig() end)