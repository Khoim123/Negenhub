-- UI/Window.lua
-- Load Fluent + tạo Window, Tabs, SaveManager, InterfaceManager
return function(S, U, GuiParent)
    local Fluent = loadstring(game:HttpGet("https://raw.githubusercontent.com/Khoim123/Fluent/refs/heads/master/Main.lua?t=" .. os.time()))()
    local SaveManager = loadstring(game:HttpGet("https://raw.githubusercontent.com/Khoim123/Fluent/master/Addons/SaveManager.lua"))()
    local InterfaceManager = loadstring(game:HttpGet("https://raw.githubusercontent.com/Khoim123/Fluent/master/Addons/InterfaceManager.lua"))()
    
    -- Inject Fluent vào Utils để notify hoạt động
    U.setFluent(Fluent)
    
    local Window = Fluent:CreateWindow({
        Title = "Negen Hub", SubTitle = "by Thanh Khôi",
        TabWidth = 120, Size = UDim2.fromOffset(520, 460),
        Acrylic = false, Theme = "Dark",
    })
    
    local Tabs = {
        Main     = Window:AddTab({ Title = "Main",     Icon = "anchor"   }),
        Shop     = Window:AddTab({ Title = "Shop",     Icon = ""         }),
        Travel   = Window:AddTab({ Title = "Travel",   Icon = ""         }),
        Others   = Window:AddTab({ Title = "Others",   Icon = ""         }),
        Settings = Window:AddTab({ Title = "Settings", Icon = "settings" }),
    }
    
    SaveManager.Folder = "KhoiScriptSettings"
    SaveManager:SetLibrary(Fluent)
    SaveManager:IgnoreThemeSettings()
    
    InterfaceManager:SetLibrary(Fluent)
    
    return {
        Fluent           = Fluent,
        Window           = Window,
        Tabs             = Tabs,
        Options          = Fluent.Options,
        SaveManager      = SaveManager,
        InterfaceManager = InterfaceManager,
    }
end