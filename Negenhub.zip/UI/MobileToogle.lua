-- UI/MobileToggle.lua
-- Nút toggle GUI cho mobile (drag) + PC (Ctrl)
return function(Shared)
    local S, U, GuiParent = Shared.Services, Shared.Utils, Shared.GuiParent
    local UserInputService = S.UserInputService
    local TweenService = S.TweenService
    local Window = Shared.Window
    local Fluent = Shared.Fluent
    
    local BTN_REST_SIZE    = 52
    local BTN_PRESS_SIZE   = 48
    local DRAG_THRESHOLD   = 8
    local MIN_VISIBLE_PX   = 4
    
    Fluent.MinimizeKey = nil
    local allowMinimize = false
    local originalMinimize = Window.Minimize
    Window.Minimize = function(self, ...)
        if allowMinimize then return originalMinimize(self, ...) end
    end
    
    local function toggleGuiVisibility()
        allowMinimize = true
        Window:Minimize()
        allowMinimize = false
    end
    
    if not UserInputService.TouchEnabled then
        UserInputService.InputBegan:Connect(function(input, gpe)
            if not gpe and input.KeyCode == Enum.KeyCode.LeftControl then
                toggleGuiVisibility()
            end
        end)
    else
        local MobileGui = U.new("ScreenGui", {
            Name = "FluentMobileToggle",
            ResetOnSpawn = false,
            DisplayOrder = 9999,
        })
        GuiParent.parentGuiSafe(MobileGui)
        
        local ToggleButton = U.new("ImageButton", {
            Name = "FluentToggleBtn",
            Size = UDim2.new(0, BTN_REST_SIZE, 0, BTN_REST_SIZE),
            Position = UDim2.new(0, 70, 0, 40),
            Image = "rbxassetid://108674032232259",
            BackgroundTransparency = 1,
        }, MobileGui)
        U.new("UICorner", { CornerRadius = UDim.new(0, 14) }, ToggleButton)
        
        local activeInput, dragStartPos, btnStartPos, dragMoved, pressTween, inputChangedConn
        
        local function clampPosition(pos)
            local vs = workspace.CurrentCamera.ViewportSize
            return UDim2.new(
                pos.X.Scale, math.clamp(pos.X.Offset, -BTN_REST_SIZE + MIN_VISIBLE_PX, vs.X - MIN_VISIBLE_PX),
                pos.Y.Scale, math.clamp(pos.Y.Offset, MIN_VISIBLE_PX, vs.Y - BTN_REST_SIZE - MIN_VISIBLE_PX)
            )
        end
        
        local function cancelState()
            activeInput, dragMoved, dragStartPos, btnStartPos = nil, false, nil, nil
            if inputChangedConn then inputChangedConn:Disconnect(); inputChangedConn = nil end
            if pressTween then pressTween:Cancel(); pressTween = nil end
            TweenService:Create(ToggleButton, TweenInfo.new(0.1), {
                Size = UDim2.new(0, BTN_REST_SIZE, 0, BTN_REST_SIZE)
            }):Play()
        end
        
        ToggleButton.InputBegan:Connect(function(input)
            if input.UserInputType ~= Enum.UserInputType.MouseButton1
                and input.UserInputType ~= Enum.UserInputType.Touch then return end
            if activeInput then return end
            activeInput = input; dragMoved = false
            dragStartPos = input.Position; btnStartPos = ToggleButton.Position
            pressTween = TweenService:Create(ToggleButton, TweenInfo.new(0.1), {
                Size = UDim2.new(0, BTN_PRESS_SIZE, 0, BTN_PRESS_SIZE)
            })
            pressTween:Play()
            inputChangedConn = input.Changed:Connect(function(prop)
                if prop == "UserInputState" and input.UserInputState == Enum.UserInputState.Cancel then
                    cancelState()
                end
            end)
        end)
        
        UserInputService.InputChanged:Connect(function(input)
            if not activeInput or input ~= activeInput then return end
            if input.UserInputType ~= Enum.UserInputType.MouseMovement
                and input.UserInputType ~= Enum.UserInputType.Touch then return end
            local delta = input.Position - dragStartPos
            if delta.Magnitude > DRAG_THRESHOLD then
                dragMoved = true
                ToggleButton.Position = clampPosition(UDim2.new(
                    btnStartPos.X.Scale, btnStartPos.X.Offset + delta.X,
                    btnStartPos.Y.Scale, btnStartPos.Y.Offset + delta.Y
                ))
            end
        end)
        
        UserInputService.InputEnded:Connect(function(input)
            if not activeInput or input ~= activeInput then return end
            local wasDragMoved = dragMoved
            cancelState()
            TweenService:Create(ToggleButton, TweenInfo.new(0.15, Enum.EasingStyle.Back), {
                Size = UDim2.new(0, BTN_REST_SIZE, 0, BTN_REST_SIZE)
            }):Play()
            if not wasDragMoved then toggleGuiVisibility() end
        end)
        
        workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function()
            if not activeInput then ToggleButton.Position = clampPosition(ToggleButton.Position) end
        end)
    end
end